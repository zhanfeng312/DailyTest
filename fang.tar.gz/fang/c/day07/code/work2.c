/*
 *
 *for练习
 */
#include <stdio.h>
int main(){
    int xun_huan = 0;
    for(xun_huan = 0;xun_huan < 3;xun_huan++){
        printf("1\n");
    }
    
    return 0;
}
/*
 * xun_huan = 0;
 * xun_huan < 3;
 *
 * {}
 * xun_huan++;
 * xun_huan < 3;
 *
 * {}
 * xun_huan++;
 * xun_huan < 3;
 *
 * {}
 * xun_huan++;
 * xun_huan < 3;
 */
    
