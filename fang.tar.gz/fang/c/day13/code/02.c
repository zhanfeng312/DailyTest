#include <stdio.h>
int main(){
    typedef enum {MAN = 6, WOMAN} gender;
    printf("WOMAN是%d\n", WOMAN);

    return 0;
}
