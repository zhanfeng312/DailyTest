/*
 *
 * printf练习
 * */

# include <stdio.h>
int main(){
    printf("\"\n");
    printf("\\\n");
    printf("%%\n");
    printf("abc\rxy\n");
    return 0;
}
