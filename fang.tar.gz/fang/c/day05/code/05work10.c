/*
 *
 *
*/
#include <stdio.h>
int main(){
    printf("%d %d %d\n",12 ,012 ,0x12);
    printf("%d 0%o 0x%x\n",18,18,18);
    printf("%p\n", 14);
    return 0;
}
