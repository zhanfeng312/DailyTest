/*
 *地址数据练习
 *
 */
# include <stdio.h>
int main(){
    int shu_zi = 3;
    printf("%d\n",shu_zi);
    printf("%d\n",*(&shu_zi));

    return 0;
}

