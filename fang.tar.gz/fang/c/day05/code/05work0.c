# include <stdio.h>
int main(){
    printf("12345\n");
    printf("%d\n",12345);
    printf("1%d5\n",234);
    printf("1%c3%c5\n",'2','4');
    printf("%d%c%d\n",12,'3',45);
    printf("%d - %d = %d\n",4000,3600,4000 - 3600);

    return 0;
}
