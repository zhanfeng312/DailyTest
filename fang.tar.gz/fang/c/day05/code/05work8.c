# include <stdio.h>
int main(){
    int i,j;
    printf("请输入你要进行的加法表达式：");
    scanf("%d     %d",&i,&j);
    printf("%d %d\n",i,j);
    return 0;
}
