/*
 *
 *数组初始化练习
 */
# include <stdio.h>
int main(){
    //int arr[3] = {1,2,3};
    //int arr[3] = {1,2,3,4,5};
    //int arr[] = {1,2,3,4,5};
    int arr[3] = {1};
    int i = 0; 
    for(i = 0;i < 3;i++){
        printf("%d ",arr[i]);
    }
        printf("\n");

    return 0;
}
