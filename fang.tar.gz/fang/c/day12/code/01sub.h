#ifndef   __SUB_H__
#define   __SUB_H__
int sub(int, int);
#endif  
