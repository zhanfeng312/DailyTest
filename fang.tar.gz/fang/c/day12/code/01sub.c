#include "01sub.h"
int sub(int value, int value1)
{
    return value - value1;
}
