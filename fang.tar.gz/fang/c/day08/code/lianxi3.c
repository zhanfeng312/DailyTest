#include<stdio.h>
int main(){
    int shu_zi = 0;
    /*
    while(1){
        printf("请输入数字:");
        scanf("%d",&shu_zi);
        if(shu_zi != 0){
            printf("%d\n",shu_zi);
        }
        else{
            break;
        }
    }*/
        scanf("%d",&shu_zi);
    while(0 != shu_zi){
        printf("请输入数字:");
        printf("%d\n",shu_zi);
    }
        

    return 0;
}
