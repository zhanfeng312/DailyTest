#include <stdio.h>
int main(void){
    int a = 2;
    printf("%*d\n", 5, a);
    return 0;
}
