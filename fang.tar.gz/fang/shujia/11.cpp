#include <iostream>
using namespace std;
int main(void){
    int a(2);
    cout << a << endl;
    return 0;
}
