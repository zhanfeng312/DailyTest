#include <stdio.h>
int main (){
    int a = 3;
    int b = 12345;
    printf("%4d,%4d\n", a, b);
    return 0;
}
