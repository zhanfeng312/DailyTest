#include <iostream>
using namespace std;
 struct Student{
    int id;
    char name[10];
};
int main (void){
    Student s;
    return 0;
}
