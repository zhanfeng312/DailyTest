#include <stdio.h>
#include <stdlib.h>
int main (){
    int i = atoi("123.456");
    printf("%d\n", i);
}
