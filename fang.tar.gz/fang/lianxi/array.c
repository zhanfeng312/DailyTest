#include <stdio.h>
typedef void (*Fun)(void);
int menu(void){
    printf("********\n");
}
int main (void){
    return 0;
}
