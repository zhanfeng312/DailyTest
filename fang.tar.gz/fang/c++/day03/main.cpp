#include "s.h"
//使用Student类
int main(){
    Student s("张飞", 20);
    s.eat("西瓜");
    return 0;
}
