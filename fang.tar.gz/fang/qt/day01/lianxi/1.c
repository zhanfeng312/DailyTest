#include <stdio.h>
int main (void) {
    int i = 1234;
    printf("%05d", i);
    return 0;
}
