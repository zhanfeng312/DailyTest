package com.inspur.net.broadcastteststatic;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.net.ConnectivityManager;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.Toast;
import android.util.Log;

public class MainActivity extends AppCompatActivity {

    private static final String TAG = "MainActivity";
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }

    public static class BootCompleteReceiver extends BroadcastReceiver {

        @Override
        public void onReceive(Context context, Intent intent) {

            String action = intent.getAction();
            Log.d(TAG, "action is " + action);

            if (action.equals(Intent.ACTION_BOOT_COMPLETED)){

                Toast.makeText(context, "Boot Complete", Toast.LENGTH_LONG).show();
            }else if (action.equals(ConnectivityManager.CONNECTIVITY_ACTION)){

                Toast.makeText(context, "Connectivity Change", Toast.LENGTH_LONG).show();
                int type = intent.getIntExtra(ConnectivityManager.EXTRA_NETWORK_TYPE, 9);

                Log.d(TAG, "type is " + type);
            }
        }
    }
}
