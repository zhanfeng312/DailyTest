package com.inspur.net;

import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;

public class T1 {

    public static void main(String[] args){

        /*
        //第一种方法：forName
        try {
            Class<?> class1 = Class.forName("com.inspur.net.Person");

            System.out.println( class1 );
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        }

        //第二张方法：class
        Class<?> class2 = Person.class;
        System.out.println( class2 );

        //第三种方法：getClass
        Person person = new Person();
        Class<?> class3 = person.getClass();

        System.out.println( class3 );
        */

        /*
        try{
            //创建类
            Class<?> class1 = Class.forName("com.inspur.net.Person");

            //获取所有的公共的方法
            Method[] methods = class1.getMethods();

            for (Method method : methods){
                System.out.println(method);
            }

        } catch(ClassNotFoundException e){
            e.printStackTrace();
        }
        */

        /*
        try{
            //创建类
            Class<?> class1 = Class.forName("com.inspur.net.Person");

            //获取所有的接口
            Class<?>[] interS = class1.getInterfaces();

            for (Class<?> class2 : interS){
                System.out.println(class2);
            }

        } catch(ClassNotFoundException e){
            e.printStackTrace();
        }
        */

        /*
        try{
            //创建类
            Class<?> class1 = Class.forName("com.inspur.net.Person");

            //获取父类
            Class<?> superclass = class1.getSuperclass();

            System.out.println(superclass);

        } catch(ClassNotFoundException e){
            e.printStackTrace();
        }
        */

        /*
        try{
            //创建类
            Class<?> class1 = Class.forName("com.inspur.net.Person");

            //获取所有的构造函数
            Constructor<?>[] constructors = class1.getConstructors();

            for(Constructor<?> constructor : constructors){
                System.out.println(constructor);
            }

        } catch(ClassNotFoundException e){
            e.printStackTrace();
        }
        */

        /*
        try{
            //创建类
            Class<?> class1 = Class.forName("com.inspur.net.Person");

            //获取本类的全部属性
            Field[] fields = class1.getDeclaredFields();

            for(Field field1 : fields){
                System.out.println(field1);
            }

        } catch(ClassNotFoundException e){
            e.printStackTrace();
        }
        */

        /*
        try {
            //创建类
            Class<?> class1 = Class.forName("com.inspur.net.Person");;

            //创建实例化：相当于 new 了一个对象
            Object object = class1.newInstance() ;

            //向下转型
            Person person = (Person) object ;

        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        } catch (InstantiationException e) {
            e.printStackTrace();
        } catch (IllegalAccessException e) {
            e.printStackTrace();
        }
        */

        /*
        try {
            //创建类
            Class<?> class1 = Class.forName("com.inspur.net.Person");;

            //获得所有的字段属性：包括
            Field[] declaredFields = class1.getDeclaredFields() ;

            Field[] fields = class1.getFields() ;

            for( Field field : declaredFields ){
                System.out.println( "de--  " +  field  );
            }

            for( Field field : fields ){
                System.out.println( "fields--  " +  field  );
            }

        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        }
        */

        try {
            //创建类
            Class<?> class1 = Class.forName("com.inspur.net.Person");

            //创建实例
            Object object = class1.newInstance();

            //获取setName方法
            Method setName = class1.getDeclaredMethod("setName", String.class);
            //打破封装
            setName.setAccessible(true);

            //调用setName方法
            setName.invoke(object,"fang");

            //获取getName方法
            Method getName = class1.getDeclaredMethod("getName");
            //打破封装
            getName.setAccessible(true);

            System.out.println(getName.getReturnType().toString());

            //执行getName方法，并且接收返回值
            String name = (String)getName.invoke(object);

            System.out.println(name);
        } catch (IllegalArgumentException e) {
            e.printStackTrace();
        } catch(InvocationTargetException e){
            e.printStackTrace();
        } catch (NoSuchMethodException e) {
            e.printStackTrace();
        } catch (InstantiationException e) {
            e.printStackTrace();
        } catch (IllegalAccessException e) {
            e.printStackTrace();
        }  catch (SecurityException e) {
            e.printStackTrace() ;
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        }
    }
}
