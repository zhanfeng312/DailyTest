package com.inspur.net;

public interface InterFace {

    public void read();
}