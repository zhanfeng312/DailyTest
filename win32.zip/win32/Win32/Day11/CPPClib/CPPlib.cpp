

int CPPlib_add(int add1, int add2)
{
	return add1 + add2;
}
int CPPlib_sub(int sub1, int sub2)
{
	return sub1 - sub2;
}