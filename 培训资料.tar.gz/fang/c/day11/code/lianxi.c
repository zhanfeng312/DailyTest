#include <stdio.h>

int main(){
    int loop = 0;

