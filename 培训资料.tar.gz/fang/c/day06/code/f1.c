#include<stdio.h>
int main(){
    int shu_zi = 0,shu_zi1 = 0;
    shu_zi = (3,7);
    printf("shu_zi是%d\n",shu_zi);
   /* printf("shu_zi是%d\n",shu_zi);
    shu_zi++;   //自增
    printf("shu_zi是%d\n",shu_zi);  
    ++shu_zi;
    printf("shu_zi是%d\n",shu_zi);  
    shu_zi--;   //自减
    printf("shu_zi是%d\n",shu_zi);   
    --shu_zi;*/
    //shu_zi1 = shu_zi++ + ++shu_zi;
    //printf("shu_zi1是%d,shu_zi是%d\n",shu_zi1,shu_zi); //16,9  


   
    return 0;
}
