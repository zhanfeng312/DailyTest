/*
 *
 *
 *
 */
  #include <stdio.h>
int main(){
 /* printf("3 == 5 是%d\n",3 == 5);
    printf("3 != 5 是%d\n",3 != 5);
    printf("3 >= 5 是%d\n",3 >= 5);
    */
    int i = 0;
    printf("3 <= 5 是%d\n",3 <= 5);     
    printf("3 < 7 < 5是%d\n",3 < 7 && 7 < 5);//逻辑运算符，结果为0/1（假或真）
    printf("3 < 7 || 7 < 5是%d\n",3 < 7 || 7 < 5);
    //3 > 5 && ++i;
    //++i && 3 > 5;
    //3 < 5 || ++i;
    //printf("!6 = %d\n",!6);

    //printf("i是%d\n",i);

    return 0;
}
