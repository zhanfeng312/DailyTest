/*
 *
 *   sizeof练习
 */
# include <stdio.h>
int main(){
    float i = 2.5;
    double j = 2.5;
//    char zi_fu = 97;
  //  printf("%c\n",zi_fu);
  //printf("%d\n",sizeof(zi_fu));
 // printf("%d\n",sizeof(char));
 //   printf("%d\n",sizeof(long long long));
     //printf("%d\n",sizeof(unsigned short));
     //printf("%d\n",sizeof(short));

   // printf("%d\n",sizeof(float));
   // printf("%d\n",sizeof(double));
   printf("%lf\n",i);
   printf("%lf\n",j);

    return 0;
}
