# include <stdio.h>
int main(){ 
    int shu_zi;
    shu_zi = 1;
    printf("%d x %d = %2d\n",shu_zi,10-shu_zi,shu_zi*(10-shu_zi));
    shu_zi = 2;
    printf("%d x %d = %2d\n",shu_zi,10-shu_zi,shu_zi*(10-shu_zi));
    shu_zi = 3;
    printf("%d x %d = %2d\n",shu_zi,10-shu_zi,shu_zi*(10-shu_zi));
    shu_zi = 4;
    printf("%d x %d = %2d\n",shu_zi,10-shu_zi,shu_zi*(10-shu_zi));
    shu_zi = 5;
    printf("%d x %d = %2d\n",shu_zi,10-shu_zi,shu_zi*(10-shu_zi));
    return 0;
}
