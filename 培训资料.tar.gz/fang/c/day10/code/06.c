include <stdio.h>
int main(){
    /*int value1 = 0,value2 = 0;
    int *p_value = &value1;      //可以表示value值
    *p_value = 5;
    printf("value1是%d\n",*p_value);

    p_value = &value2;          //可以表示value1值
    *p_value = 7;

    printf("value2是%d\n",*p_value);
    printf("value1是%d\n",*p_value + value1);*/
   /* int values[2];
    int *p_value = values;  //values表示下标为0的地址
    *p_value = 5;
    p_value++;              //表示下标为1的地址
    *p_value = 7;
    *(p_value - 1) += *p_value;*/

    return 0;
}
