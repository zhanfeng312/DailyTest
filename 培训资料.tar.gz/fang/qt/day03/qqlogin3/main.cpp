#include <QtGui/QApplication>
#include "qqlogin.h"

int main(int argc, char *argv[])
{
    QApplication a(argc, argv);
    QqLogin w;
    w.show();
    
    return a.exec();
}
