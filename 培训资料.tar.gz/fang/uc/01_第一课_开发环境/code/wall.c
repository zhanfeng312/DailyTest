#include <stdio.h>

foo () {}

int main (void) {
	printf ("%d\n", foo ());
	return 0;
}
