#include <stdio.h>
#include "calc.h"

int main (void) {
	printf ("%lf\n", add (10, 20));
	return 0;
}
