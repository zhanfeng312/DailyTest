#include "math.h"

int main (void) {
	show (30, '+', 20, add (30, 20));
	show (30, '-', 20, sub (30, 20));
	return 0;
}
