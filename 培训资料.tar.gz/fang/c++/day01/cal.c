#include <stdio.h>
extern int add(int, int);
int main() {
    printf("%d\n", add(10, 20));
    return 0;
}
