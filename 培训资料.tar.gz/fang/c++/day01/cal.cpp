#include <iostream>
#include "math.h"
using namespace std;
//extern int add(int, int);
//extern int a = 1;
int main() {
    //printf("%d\n", add(10, 20));
    return 0;
}
